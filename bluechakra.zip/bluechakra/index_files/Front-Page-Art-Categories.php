<div id="sidebar">
   <ul>
      <?php
      if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front-Page-Art-Categories') ) :
      endif; ?>
   </ul>
</div>